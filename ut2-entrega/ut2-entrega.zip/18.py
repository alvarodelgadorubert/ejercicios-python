entrada = input("Ingresa un número: ")
es_numerico = entrada.isnumeric()

print(f"¿Todos los caracteres son numéricos? {es_numerico}")