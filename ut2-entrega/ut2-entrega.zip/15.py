mensaje = input("Escribe un mensaje corto: ")
nueva_cadena = f"\n\t\"{mensaje}\""

print(nueva_cadena)