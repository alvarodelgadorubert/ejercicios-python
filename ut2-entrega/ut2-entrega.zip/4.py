frase = "Python es genial"

print(frase[0])      # Primer carácter
print(frase[-1])     # Último carácter
print(frase[7:10])   # Caracteres del índice 7 al 9