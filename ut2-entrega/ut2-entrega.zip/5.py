numero_cadena = input("Ingresa un número: ")
numero_entero = int(numero_cadena)
resultado = numero_entero * 10

print(f"El número multiplicado por 10 es: {resultado}")