frase = input("Introduce una frase: ")
longitud = len(frase)

print(f"La frase tiene {longitud} caracteres.")