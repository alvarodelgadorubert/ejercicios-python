palabra = input("Escribe una palabra: ")
resultado = 'a' in palabra

print(f"¿La letra 'a' está en la palabra? {resultado}")