titulo = input("Título del libro: ")
autor = input("Autor del libro: ")
año = input("Año de publicación: ")
genero = input("Género: ")

libro = f"""Título: {titulo}
Autor: {autor}
Año: {año}
Género: {genero}"""

print(libro)