frase = input("Escribe una frase: ")

print(frase.upper())      # Mayúsculas
print(frase.lower())      # Minúsculas
print(frase.title())      # Formato título