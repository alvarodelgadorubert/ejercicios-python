cadena = "Esta es una 'cadena' con comillas dobles,\nun salto de línea y \tuna tabulación."
print(cadena)