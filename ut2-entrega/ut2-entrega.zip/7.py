frase = input("Escribe una frase: ")

print(frase[:5])                          # Primeros 5 caracteres
print(frase[-5:])                         # Últimos 5 caracteres
print(frase[::2])                         # Caracteres en posiciones pares