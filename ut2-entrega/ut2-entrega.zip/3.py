palabra = input("Escribe una palabra: ")
numero = int(input("Escribe un número: "))

resultado = palabra * numero
print(resultado)