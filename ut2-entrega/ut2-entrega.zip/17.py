palabra1 = input("Ingresa la primera palabra: ")
palabra2 = input("Ingresa la segunda palabra: ")

print(f"¿Las palabras son iguales? {palabra1 == palabra2}")
print(f"¿La primera palabra es mayor lexicográficamente? {palabra1 > palabra2}")