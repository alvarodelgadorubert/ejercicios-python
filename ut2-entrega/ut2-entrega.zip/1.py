cadena1 = 'Cadena con comillas simples'
cadena2 = "Cadena con comillas dobles"
cadena3 = """Cadena con comillas triples
que puede tener
varias líneas"""

print(cadena1)
print(cadena2)
print(cadena3)