frase = input("Ingresa una frase: ")

print(frase[:10])                    # Primeros 10 caracteres
print(frase[-10:])                   # Últimos 10 caracteres
print(frase[5:16])                   # Posición 5 a 15
print(frase[::-1])                   # Frase en orden inverso