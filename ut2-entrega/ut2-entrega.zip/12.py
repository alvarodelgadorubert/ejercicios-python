asignatura = input("Escribe el nombre de tu asignatura favorita: ")
creditos = input("Ingresa el número de créditos: ")
calificacion = input("Ingresa tu calificación: ")

mensaje = f"Mi asignatura favorita es {asignatura}, tiene {creditos} créditos y obtuve una calificación de {calificacion}."
print(mensaje)