nombre = input("Ingresa tu nombre: ")
apellido = input("Ingresa tu apellido: ")
ciudad = input("Ingresa tu ciudad de nacimiento: ")

mensaje = f"Hola, mi nombre es {nombre} {apellido} y nací en {ciudad}."
print(mensaje)