# Calcular el km en el que se encuentran 2 coches
km1 = 70
km2 = 150

while km1 != km2:
    km1 += 1  
    km2 -= 1  

print("Se encuentran en el km:", km1)
