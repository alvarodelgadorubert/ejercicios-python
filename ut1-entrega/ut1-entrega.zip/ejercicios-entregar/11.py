num1 = float(input("Ingresa el primer número: "))
num2 = float(input("Ingresa el segundo número: "))
distancia = abs(num1 - num2)
print(f"La distancia entre {num1} y {num2} es: {distancia}")