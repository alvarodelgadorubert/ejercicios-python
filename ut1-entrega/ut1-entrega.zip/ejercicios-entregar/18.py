nombre = input("Ingresa tu nombre: ")
apellido1 = input("Ingresa tu primer apellido: ")
apellido2 = input("Ingresa tu segundo apellido: ")
iniciales = nombre[0] + apellido1[0] + apellido2[0]
print(f"Las iniciales son: {iniciales.upper()}")