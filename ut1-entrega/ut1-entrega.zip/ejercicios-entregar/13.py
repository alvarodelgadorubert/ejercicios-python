import math
numero = float(input("Ingresa un número: "))
raiz_cuadrada = math.sqrt(numero)
raiz_cubica = numero ** (1/3)
print(f"Raíz cuadrada: {raiz_cuadrada:.2f}")
print(f"Raíz cúbica: {raiz_cubica:.2f}")