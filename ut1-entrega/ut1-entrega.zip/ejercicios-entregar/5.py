fahrenheit = float(input("Ingresa los grados Fahrenheit: "))
celsius = (fahrenheit - 32) * 5 / 9
print(f"{fahrenheit}°F equivalen a {celsius:.2f}°C")