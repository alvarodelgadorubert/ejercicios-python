a = float(input("Ingresa el valor de A: "))
b = float(input("Ingresa el valor de B: "))
print(f"Valores originales - A: {a}, B: {b}")
# Intercambiar valores
a, b = b, a
print(f"Valores intercambiados - A: {a}, B: {b}")