base = float(input("Ingresa la base del rectángulo: "))
altura = float(input("Ingresa la altura del rectángulo: "))
perimetro = 2 * (base + altura)
area = base * altura
print(f"Perímetro: {perimetro}")
print(f"Área: {area}")